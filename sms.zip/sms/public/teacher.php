<?php
session_start();

require_once __DIR__ . '/../app/controllers/TeacherController.php';

$controller = new TeacherController();
$action = $_GET['action'] ?? 'dashboard';

switch ($action) {

    case 'attendance':
        $controller->attendance();
        break;

    case 'saveAttendance':
        $controller->saveAttendance();
        break;

    case 'marks':
        $controller->marks();
        break;

    case 'saveMarks':
        $controller->saveMarks();
        break;

    default:
        $controller->dashboard();
        break;
}
