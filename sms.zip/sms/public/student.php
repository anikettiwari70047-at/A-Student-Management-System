<?php
session_start();

require_once __DIR__ . '/../app/controllers/StudentController.php';

$controller = new StudentController();
$action = $_GET['action'] ?? 'dashboard';

switch ($action) {

    case 'attendance':
        $controller->attendance();
        break;

    case 'marks':
        $controller->marks();
        break;

    default:
        $controller->dashboard();
        break;
}
