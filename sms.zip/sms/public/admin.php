<?php
session_start();

require_once __DIR__ . '/../app/controllers/AdminController.php';

$controller = new AdminController();
$action = $_GET['action'] ?? 'dashboard';

switch ($action) {

    case 'addStudent':
        $controller->addStudent();
        break;

    case 'storeStudent':
        $controller->storeStudent();
        break;

    case 'listStudents':
        $controller->listStudents();
        break;

    case 'editStudent':
        $controller->editStudent();
        break;

    case 'updateStudent':
        $controller->updateStudent();
        break;

    case 'deleteStudent':
        $controller->deleteStudent();
        break;

    default:
        $controller->dashboard();
        break;
}
