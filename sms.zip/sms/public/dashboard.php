<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/sms/public/css/style.css">
</head>
<body>

<div class="navbar">
    <ul>
        <li><a href="/sms/public/dashboard.php">Dashboard</a></li>
        <li><a href="/sms/public/admin.php?action=listStudents">Students</a></li>
        <li class="right"><a href="/sms/public/logout.php">Logout</a></li>
    </ul>
</div>

<div class="container">
    <h2>Admin Dashboard</h2>

    <div class="card-grid">

        <a class="card" href="/sms/public/admin.php?action=listStudents">
            <img src="/sms/public/images/students.png" alt="Students">
            <span>Manage Students</span>
        </a>

        <a class="card" href="/sms/public/admin.php?action=addStudent">
            <img src="/sms/public/images/add.png" alt="Add Student">
            <span>Add Student</span>
        </a>

        <a class="card logout-card" href="/sms/public/logout.php">
            <img src="/sms/public/images/logout.png" alt="Logout">
            <span>Logout</span>
        </a>

    </div>
</div>

</body>
</html>
