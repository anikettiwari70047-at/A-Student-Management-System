<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../models/Student.php';
require_once __DIR__ . '/../models/Attendance.php';
require_once __DIR__ . '/../models/Marks.php';

class StudentController
{
    private function auth()
    {
        if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
            header("Location: /sms/public/");
            exit;
        }
    }

    public function dashboard()
    {
        $this->auth();
        require __DIR__ . '/../views/student/dashboard.php';
    }

    public function attendance()
    {
        $this->auth();

        $studentModel = new Student();
        $student = $studentModel->findByUserId($_SESSION['user_id']);

        if (!$student) {
            die("Student record not linked to user");
        }

        $attendanceModel = new Attendance();
        $attendance = $attendanceModel->getByStudentId($student['id']);

        require __DIR__ . '/../views/student/attendance.php';
    }

    public function marks()
    {
        $this->auth();

        $studentModel = new Student();
        $student = $studentModel->findByUserId($_SESSION['user_id']);

        if (!$student) {
            die("Student record not linked to user");
        }

        $marksModel = new Marks();
        $marks = $marksModel->getByStudentId($student['id']);

        require __DIR__ . '/../views/student/marks.php';
    }
}
