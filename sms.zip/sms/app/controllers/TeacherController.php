<?php

require_once __DIR__ . '/../core/Middleware.php';
require_once __DIR__ . '/../models/Student.php';
require_once __DIR__ . '/../models/Attendance.php';
require_once __DIR__ . '/../models/Marks.php';

class TeacherController
{
    // 🔐 Role protection
    private function auth(): void
    {
        Middleware::auth('teacher');
    }

    // 📊 Dashboard
    public function dashboard(): void
    {
        $this->auth();
        require '../app/views/teacher/dashboard.php';
    }

    // 📝 Attendance page
    public function attendance(): void
    {
        $this->auth();

        $student = new Student();
        $students = $student->all();

        require '../app/views/teacher/attendance.php';
    }

    // 💾 Save attendance
    public function saveAttendance(): void
    {
        $this->auth();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $attendance = new Attendance();
            $date = date('Y-m-d');

            if (isset($_POST['status'])) {
                foreach ($_POST['status'] as $student_id => $status) {
                    $attendance->mark($student_id, $date, $status);
                }
            }

            header("Location: /sms/public/teacher.php?action=attendance");
            exit;
        }
    }

    // 🧮 Marks page
    public function marks(): void
    {
        $this->auth();

        $student = new Student();
        $students = $student->all();

        require '../app/views/teacher/marks.php';
    }

    // 💾 SAVE MARKS (FIXED)
    public function saveMarks(): void
    {
        $this->auth();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $marksModel = new Marks();

            if (isset($_POST['marks'])) {
                foreach ($_POST['marks'] as $student_id => $marks) {
                    $marksModel->save($student_id, $marks);
                }
            }

            header("Location: /sms/public/teacher.php?action=marks");
            exit;
        }
    }
}
