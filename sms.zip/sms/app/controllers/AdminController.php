<?php

require_once __DIR__ . '/../models/Student.php';

class AdminController
{
    private function auth()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
            header("Location: /sms/public/");
            exit;
        }
    }

    public function dashboard()
    {
        $this->auth();
        require '../app/views/admin/dashboard.php';
    }

    public function addStudent()
    {
        $this->auth();
        require '../app/views/admin/add_student.php';
    }

    public function storeStudent()
    {
        $this->auth();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $student = new Student();
            $student->create($_POST['name'], $_POST['email'], $_POST['course']);
            header("Location: /sms/public/admin.php?action=listStudents");
            exit;
        }
    }

    public function listStudents()
    {
        $this->auth();
        $student = new Student();
        $students = $student->all();
        require '../app/views/admin/list_students.php';
    }

    public function editStudent()
    {
        $this->auth();
        $student = new Student();
        $data = $student->find($_GET['id']);
        require '../app/views/admin/edit_student.php';
    }

    public function updateStudent()
    {
        $this->auth();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $student = new Student();
            $student->update(
                $_POST['id'],
                $_POST['name'],
                $_POST['email'],
                $_POST['course']
            );
            header("Location: /sms/public/admin.php?action=listStudents");
            exit;
        }
    }

    // 🔴 DELETE STUDENT
    public function deleteStudent()
    {
        $this->auth();

        if (isset($_GET['id'])) {
            $student = new Student();
            $student->delete($_GET['id']);
        }

        header("Location: /sms/public/admin.php?action=listStudents");
        exit;
    }
}
