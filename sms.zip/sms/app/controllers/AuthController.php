<?php

require_once __DIR__ . '/../core/Auth.php';

class AuthController
{
    public function login()
    {
        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';

            if (!Auth::login($username, $password)) {
                $error = "Invalid credentials";
            }
        }

        require __DIR__ . '/../views/auth/login.php';
    }
}
