<?php

class Database
{
    private static $conn = null;

    public static function connect()
    {
        if (self::$conn === null) {
            self::$conn = new mysqli("localhost", "root", "", "sms_db");

            if (self::$conn->connect_error) {
                die("Database connection failed");
            }
        }

        return self::$conn;
    }
}
