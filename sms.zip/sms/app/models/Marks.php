<?php

require_once __DIR__ . '/../config/database.php';

class Marks
{
    private $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }

    // 🔹 Get marks for a student
    public function getByStudentId($studentId)
    {
        $stmt = $this->db->prepare(
            "SELECT subject, marks FROM marks WHERE student_id = ?"
        );
        $stmt->bind_param("i", $studentId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function save($studentId, $marks)
    {
        $subject = $_POST['subject'] ?? 'General';

        $stmt = $this->db->prepare("INSERT INTO marks (student_id, subject, marks) VALUES (?, ?, ?)");
        $stmt->bind_param("isi", $studentId, $subject, $marks);
        return $stmt->execute();
    }
}
