<?php

require_once __DIR__ . '/../config/database.php';

class Attendance
{
    private $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }

    // SAVE / UPDATE ATTENDANCE (TEACHER)
    public function mark($student_id, $date, $status): bool
    {
        $sql = "
            INSERT INTO attendance (student_id, date, status)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE status = ?
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("isss", $student_id, $date, $status, $status);

        return $stmt->execute();
    }

    // FETCH ATTENDANCE FOR STUDENT
    public function getByStudentId($student_id): array
    {
        $sql = "
            SELECT date, status
            FROM attendance
            WHERE student_id = ?
            ORDER BY date DESC
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $student_id);
        $stmt->execute();

        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}
