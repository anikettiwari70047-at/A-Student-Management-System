<?php

require_once __DIR__ . '/../config/database.php';

class Student
{
    private $db;

    public function __construct()
    {
        $this->db = Database::connect();
    }

    // ✅ REQUIRED BY TEACHER MODULE
    public function all()
    {
        $result = $this->db->query("SELECT * FROM students");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // ✅ REQUIRED BY STUDENT MODULE
    public function findByUserId($user_id)
    {
        $stmt = $this->db->prepare("SELECT * FROM students WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function create($name, $email, $course)
    {
        $stmt = $this->db->prepare("INSERT INTO students (name, email, course) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $course);
        return $stmt->execute();
    }

    public function find($id)
    {
        $stmt = $this->db->prepare("SELECT * FROM students WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function update($id, $name, $email, $course)
    {
        $stmt = $this->db->prepare("UPDATE students SET name = ?, email = ?, course = ? WHERE id = ?");
        $stmt->bind_param("sssi", $name, $email, $course, $id);
        return $stmt->execute();
    }

    public function delete($id)
    {
        $stmt = $this->db->prepare("DELETE FROM students WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
