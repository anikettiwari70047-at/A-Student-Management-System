<h2>Mark Attendance</h2>

<form method="post" action="/sms/public/teacher.php?action=saveAttendance">
    <table border="1" cellpadding="10">
        <tr>
            <th>Name</th>
            <th>Present</th>
            <th>Absent</th>
        </tr>

        <?php foreach ($students as $student): ?>
        <tr>
            <td><?= $student['name'] ?></td>
            <td>
                <input type="radio" name="status[<?= $student['id'] ?>]" value="Present" required>
            </td>
            <td>
                <input type="radio" name="status[<?= $student['id'] ?>]" value="Absent">
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <br>
    <button type="submit">Save Attendance</button>
</form>

<br>
<a href="/sms/public/teacher.php">⬅ Back to Dashboard</a>
