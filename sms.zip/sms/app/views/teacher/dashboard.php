<!DOCTYPE html>
<html>
<head>
    <title>Teacher Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/sms/public/css/style.css">
</head>
<body>

<div class="navbar">
    <ul>
        <li><a href="/sms/public/teacher.php">Dashboard</a></li>
        <li><a href="/sms/public/teacher.php?action=attendance">Attendance</a></li>
        <li><a href="/sms/public/teacher.php?action=marks">Marks</a></li>
        <li class="right"><a href="/sms/public/logout.php">Logout</a></li>
    </ul>
</div>

<div class="container">
    <h2>Teacher Dashboard</h2>
    <p>Welcome, Teacher. Use the navigation bar to manage attendance and marks.</p>
</div>

</body>
</html>
