<h2>Enter Marks</h2>

<form method="post" action="/sms/public/teacher.php?action=saveMarks">

    <label>Subject:</label>
    <input type="text" name="subject" required>
    <br><br>

    <table border="1" cellpadding="10">
        <tr>
            <th>Name</th>
            <th>Marks</th>
        </tr>

        <?php foreach ($students as $student): ?>
        <tr>
            <td><?= $student['name'] ?></td>
            <td>
                <input type="number" name="marks[<?= $student['id'] ?>]" required>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <br>
    <button type="submit">Save Marks</button>
</form>

<br>
<a href="/sms/public/teacher.php">⬅ Back to Dashboard</a>
