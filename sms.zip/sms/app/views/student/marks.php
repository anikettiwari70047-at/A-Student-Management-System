<h2>My Marks</h2>

<?php if (empty($marks)): ?>
    <p>No marks found.</p>
<?php else: ?>
<table border="1" cellpadding="8">
    <tr>
        <th>Subject</th>
        <th>Marks</th>
    </tr>
    <?php foreach ($marks as $m): ?>
        <tr>
            <td><?= htmlspecialchars($m['subject']) ?></td>
            <td><?= htmlspecialchars($m['marks']) ?></td>
        </tr>
    <?php endforeach; ?>
</table>
<?php endif; ?>

<br>
<a href="student.php">← Back to Dashboard</a>
