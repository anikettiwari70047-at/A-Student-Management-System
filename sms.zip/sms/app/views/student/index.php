<h2>Students</h2>

<a href="/sms/public/admin.php?action=create-student">Add Student</a>

<table border="1" cellpadding="8">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Course</th>
    <th>Actions</th>

</tr>

<?php foreach ($students as $s): ?>
<tr>
    <td><?= $s['id'] ?></td>
    <td><?= $s['name'] ?></td>
    <td><?= $s['email'] ?></td>
    <td><?= $s['course'] ?></td>
    <td>
    <a href="/sms/public/admin.php?action=edit-student&id=<?= $s['id'] ?>">Edit</a> |
    <a href="/sms/public/admin.php?action=delete-student&id=<?= $s['id'] ?>"
       onclick="return confirm('Are you sure?')">Delete</a>
</td>

</tr>
<?php endforeach; ?>
</table>
