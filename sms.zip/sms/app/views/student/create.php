<h2>Add Student</h2>

<form method="POST">
    <input name="name" placeholder="Student Name" required><br><br>
    <input name="email" placeholder="Email" required><br><br>
    <input name="course" placeholder="Course" required><br><br>
    <button type="submit">Save</button>
</form>
