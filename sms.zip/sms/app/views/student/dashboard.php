<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/sms/public/css/style.css">
</head>
<body>

<div class="navbar">
    <ul>
        <li><a href="/sms/public/student.php">Dashboard</a></li>
        <li><a href="/sms/public/student.php?action=attendance">Attendance</a></li>
        <li><a href="/sms/public/student.php?action=marks">Marks</a></li>
        <li class="right"><a href="/sms/public/logout.php">Logout</a></li>
    </ul>
</div>

<div class="container">
    <h2>Student Dashboard</h2>
    <p>Welcome. Use the navigation bar to view your academic records.</p>
</div>

</body>
</html>
