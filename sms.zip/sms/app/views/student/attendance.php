<h2>My Attendance</h2>

<?php if (!empty($attendance)): ?>
<table border="1" cellpadding="10">
    <tr>
        <th>Date</th>
        <th>Status</th>
    </tr>

    <?php foreach ($attendance as $row): ?>
    <tr>
        <td><?= $row['date'] ?></td>
        <td><?= $row['status'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>
<?php else: ?>
<p>No attendance records found.</p>
<?php endif; ?>

<br>
<a href="/sms/public/student.php">⬅ Back to Dashboard</a>
