<h2>Edit Student</h2>

<form method="POST">
    <input name="name" value="<?= $data['name'] ?>" required><br><br>
    <input name="email" value="<?= $data['email'] ?>" required><br><br>
    <input name="course" value="<?= $data['course'] ?>" required><br><br>
    <button type="submit">Update</button>
</form>
