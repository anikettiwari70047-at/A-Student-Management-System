<!DOCTYPE html>
<html>
<head>
    <title>Student List</title>
    <link rel="stylesheet" href="/sms/public/css/style.css">
</head>
<body>

<div class="container">
    <h2>Student List</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Course</th>
            <th>Action</th>
        </tr>

        <?php foreach ($students as $student): ?>
        <tr>
            <td><?= $student['id'] ?></td>
            <td><?= $student['name'] ?></td>
            <td><?= $student['email'] ?></td>
            <td><?= $student['course'] ?></td>
            <td>
                <a href="/sms/public/admin.php?action=editStudent&id=<?= $student['id'] ?>">Edit</a> |
                <a href="/sms/public/admin.php?action=deleteStudent&id=<?= $student['id'] ?>"
                   onclick="return confirm('Delete this student?')">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <a href="/sms/public/admin.php?action=addStudent">➕ Add Student</a>
</div>

</body>
</html>
