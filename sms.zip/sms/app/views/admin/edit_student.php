<h2>Edit Student</h2>

<form method="post" action="/sms/public/admin.php?action=updateStudent">
    <input type="hidden" name="id" value="<?= $data['id'] ?>">

    <label>Name:</label><br>
    <input type="text" name="name" value="<?= $data['name'] ?>" required><br><br>

    <label>Email:</label><br>
    <input type="email" name="email" value="<?= $data['email'] ?>" required><br><br>

    <label>Course:</label><br>
    <input type="text" name="course" value="<?= $data['course'] ?>" required><br><br>

    <button type="submit">Update Student</button>
</form>

<br>
<a href="/sms/public/admin.php?action=listStudents">⬅ Back to List</a>
