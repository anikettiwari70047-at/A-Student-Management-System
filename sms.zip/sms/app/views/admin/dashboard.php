<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/sms/public/css/style.css">
</head>
<body>

<div class="navbar">
    <ul>
        <li><a href="/sms/public/dashboard.php">Dashboard</a></li>
        <li><a href="/sms/public/admin.php?action=addStudent">Add Student</a></li>
        <li><a href="/sms/public/admin.php?action=listStudents">Students</a></li>
        <li class="right"><a href="/sms/public/logout.php">Logout</a></li>
    </ul>
</div>

<div class="container">
    <h2>Admin Dashboard</h2>
    <p>Welcome, Admin. Use the navigation bar to manage students.</p>
</div>

</body>
</html>
