<!DOCTYPE html>
<html>
<head>
    <title>Add Student</title>
    <link rel="stylesheet" href="/sms/public/css/style.css">
</head>
<body>

<div class="container">
    <h2>Add Student</h2>

    <form method="post" action="/sms/public/admin.php?action=storeStudent">
        <label>Name</label>
        <input type="text" name="name" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Course</label>
        <input type="text" name="course" required>

        <button type="submit">Add Student</button>
    </form>

    <br>
    <a href="/sms/public/admin.php?action=listStudents">⬅ Back</a>
</div>

</body>
</html>
