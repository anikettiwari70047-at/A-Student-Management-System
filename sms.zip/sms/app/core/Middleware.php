<?php
class Middleware {

    public static function auth($role) {

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['role'])) {
            header("Location: /sms/public/");
            exit;
        }

        if ($_SESSION['role'] !== $role) {
            echo "Access denied";
            exit;
        }
    }
}

