<?php

class Auth
{
    public static function login($username, $password)
    {
        require_once __DIR__ . '/../config/database.php';

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $db = new Database();
        $conn = $db->connect();

        $stmt = $conn->prepare("
            SELECT users.*, roles.name AS role_name
            FROM users
            JOIN roles ON users.role_id = roles.id
            WHERE users.username = ?
        ");
        $stmt->bind_param("s", $username);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {

            // 🔐 SECURE PASSWORD CHECK
            if (password_verify($password, $user['password'])) {

                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role']    = $user['role_name'];

                if ($user['role_name'] === 'admin') {
                    header("Location: /sms/public/dashboard.php");
                    exit;
                }

                if ($user['role_name'] === 'teacher') {
                    header("Location: /sms/public/teacher.php");
                    exit;
                }

                if ($user['role_name'] === 'student') {
                    header("Location: /sms/public/student.php");
                    exit;
                }
            }
        }

        return false;
    }
}
